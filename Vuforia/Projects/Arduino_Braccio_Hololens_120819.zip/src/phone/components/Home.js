// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available


// --------------------- GAUGES --------------------------------------

$scope.foo = function() {
  
   	$scope.app.params.testParameter = 0.2; 
	// do something  
}



// Make spec image visible
$scope.showSpecs = function() {
 
  // Specification 1
  if ($scope.view.wdg['servo_specs']['visible']) {                                            
  $scope.view.wdg['servo_specs']['visible'] = false;
  } 
  else {
    $scope.view.wdg['servo_specs']['visible'] = true;
  }
  
  // Specification 2
  if ($scope.view.wdg['servo2_specs']['visible']) {                                            
  $scope.view.wdg['servo2_specs']['visible'] = false;
  } 
  else {
    $scope.view.wdg['servo2_specs']['visible'] = true;
  }
 
 }



//-------------------Robot animation---------------------------



$scope.startRobot = function() {
  
    // evaluates the function at intervals specified by the timingInterval variable
    timerId = setInterval(function() {
        // ensure parameter values
        $scope.app.params.base_ry = 20;
        $scope.app.params.lowerArm_rx = 20;

      

        $scope.app.params.base_ry += delta_base_ry;
        $scope.app.params.lowerArm_rx += delta_lowerArm_rx;
        $scope.app.params.middleArm_rx += delta_middleArm_rx;
  

    }, 1);
}




//-----------------------------------------------------------------------
