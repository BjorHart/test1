// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available

// Trigger alert when getpropertyvalues service is executed -------------------------------

$scope.$root.$on("GetPropertyValues-complete", function(event, args) {
	if (args.data["0"].TriggerAlert == true) {
        $scope.view.wdg['alert']['visible'] = true;
        $scope.view.wdg['alert_text']['visible'] = true;
    }  
  	else {
        $scope.view.wdg['alert']['visible'] = false;
        $scope.view.wdg['alert_text']['visible'] = false;

    }

});	

//-------------------------------------------------------------------------------------------

// Chart js -----------------------------------------------------------------------------------
 // Chart Legends
Chart.defaults.global.legend.position="bottom";
Chart.defaults.global.legend.display=false;
Chart.defaults.global.legend.labels.fontColor="#000000";
Chart.defaults.global.defaultFontColor="#0000ff";
Chart.defaults.global.defaultFontSize=10;
Chart.defaults.global.title.display=false;

//For timeseries LINES
//Chart.defaults.global.elements.line.backgroundColor="#ffffff";
Chart.defaults.global.elements.line.borderColor='rgba(0, 50, 255, 0.7)';

// for time series POINTS
Chart.defaults.global.elements.point.backgroundColor="#ffffff";
Chart.defaults.global.elements.point.borderColor="#007777";
Chart.defaults.global.elements.point.radius=2;

//----------------------------------------------------------------------------

// function to redirect to edr home page
$scope.goToEDR = function () {
	window.location.href = 'https://edrmedeso.com/'	  
}



//------------------------------------------------------ Highlight individual parts -------------------------------

var highlightActive = true;
var showAnglesActive = true;
var yellow = 'rgba(238,238,0,1)';
var orange = 'rgba(211,84,0,1)';
var white = 'rgba(255,253,208,1)';
var black = 'rgba(0,0,0,1)';


//------------------------- New Code here ----------------------------


// Highlight engine
$scope.highlight = function(type) {
  	if (highlightActive == true) {
      	// Always hide angle display
        $scope.view.wdg['display_angles']['visible'] = false;
      	showAnglesActive = false;

        if ($scope.view.wdg[type].color == yellow) {
          // Reset color and opacity
          $scope.view.wdg['base_engine'].color = black;
          $scope.view.wdg['lower_engine'].color = black;
          $scope.view.wdg['middle_engine'].color = black;
          $scope.view.wdg['upper_engine'].color = black;
          $scope.view.wdg['gripper_engine1'].color = black;
          $scope.view.wdg['gripper_engine2'].color = black;
          $scope.view.wdg['middle_housing'].color = black;
          $scope.view.wdg['upper_housing'].color = black;
          $scope.view.wdg['basePlate'].opacity = 1;
          $scope.view.wdg['base_separate'].opacity = 1;
          $scope.view.wdg['upper_arm_separate'].opacity = 1;
          $scope.view.wdg['middle_arm_separate'].opacity = 1;
          $scope.view.wdg['lower_arm_separate'].opacity = 1;
          $scope.view.wdg['gripper'].opacity = 1;
          $scope.view.wdg['servo_specs']['visible'] = false;
    	  $scope.view.wdg['servo2_specs']['visible'] = false;
          // Allow displaying angles again
          showAnglesActive = true;
        } 	
        else {
          // Set opacaties
          $scope.view.wdg[type].color = yellow;
          
            if (type == 'base_engine') {
				$scope.view.wdg['basePlate'].opacity = 0.2;
                $scope.view.wdg['base_separate'].opacity = 0.2;
                $scope.view.wdg['servo_specs']['visible'] = true;
            }
          	if (type == 'lower_engine') {
              	$scope.view.wdg['basePlate'].opacity = 0.2;
                $scope.view.wdg['base_separate'].opacity = 0.2;
				$scope.view.wdg['lower_arm_separate'].opacity = 0.2;
                $scope.view.wdg['servo_specs']['visible'] = true;
            }
          	if (type == 'middle_engine' || type == 'middle_housing') {
				$scope.view.wdg['lower_arm_separate'].opacity = 0.2;
      			$scope.view.wdg['middle_arm_separate'].opacity = 0.2;
            }
			if (type == 'middle_engine') {
                $scope.view.wdg['servo_specs']['visible'] = true;
            }
          	if (type == 'upper_engine' || type == 'upper_housing') {
				$scope.view.wdg['middle_arm_separate'].opacity = 0.2;
				$scope.view.wdg['upper_arm_separate'].opacity = 0.2;
            }
            if (type == 'upper_engine') {
                $scope.view.wdg['servo_specs']['visible'] = true;
            }
            if (type == 'gripper_engine1') {
				$scope.view.wdg['upper_arm_separate'].opacity = 0.2;
				$scope.view.wdg['gripper'].opacity = 0.2;
                $scope.view.wdg['servo2_specs']['visible'] = true;
            }
            if (type == 'gripper_engine2') {
				$scope.view.wdg['gripper'].opacity = 0.2;
                $scope.view.wdg['servo2_specs']['visible'] = true;
            }
        }
    }
}


$scope.showAngles = function() {
  	if (showAnglesActive) {
      // Hide spec displays
      $scope.view.wdg['servo_specs']['visible'] = false;
      $scope.view.wdg['servo2_specs']['visible'] = false;

      if ($scope.view.wdg['display_angles']['visible'] == false) {
          // Show angle display
          $scope.view.wdg['display_angles']['visible'] = true;
          $scope.view.wdg['h1']['visible'] = true;

      }
      else {
          // Hide angle display
          $scope.view.wdg['display_angles']['visible'] = false;
          $scope.view.wdg['h1']['visible'] = false;

      }
    }
}




//----------------------- Animation code ----------------------------------------------------------------------





// variables used for animation
var timerId = -1;
var timingInterval = 30; // milliseconds

// variables used for moving the robot
var delta_base_ry = 0;
var delta_lowerArm_rx = 0;
var delta_middleArm_rx = 0;
var delta_upperArm_rx = 0;

// invoked by Power button 'Pressed' event
$scope.startRobot = function() {
    if (timerId > -1) { clearInterval(timerId); }

    // evaluates the function at intervals specified by the timingInterval variable
    timerId = setInterval(function() {
        // ensure parameter values
        if (!$scope.app.params.base_ry) { $scope.app.params.base_ry = 0; }
        if (!$scope.app.params.lowerArm_rx) { $scope.app.params.lowerArm_rx = 0; }
        if (!$scope.app.params.middleArm_rx) { $scope.app.params.middleArm_rx = 0; }
        if (!$scope.app.params.upperArm_rx) { $scope.app.params.upperArm_rx = 0; }

        // animates the robot
        $scope.$apply(function() {
            // move
            $scope.app.params.base_ry += delta_base_ry;
            $scope.app.params.lowerArm_rx += delta_lowerArm_rx;
            $scope.app.params.middleArm_rx += delta_middleArm_rx;
            $scope.app.params.upperArm_rx += delta_upperArm_rx;
        });

    }, timingInterval);
}


// functions used by toggling the 'Pressed' and 'Unpressed' events
$scope.rotbaseLeft  = function() { delta_base_ry = 0.5; }
$scope.rotbaseRight = function() { delta_base_ry = -0.5; }
$scope.stopbase     = function() { delta_base_ry = 0; }

$scope.rotLowerArmLeft  = function() { delta_lowerArm_rx = 0.5; }
$scope.rotLowerArmRight = function() { delta_lowerArm_rx = -0.5; }
$scope.stopLowerArm     = function() { delta_lowerArm_rx = 0; }


$scope.rotMiddleArmLeft  = function() { delta_middleArm_rx = 0.5; }
$scope.rotMiddleArmRight = function() { delta_middleArm_rx = -0.5; }
$scope.stopMiddleArm     = function() { delta_middleArm_rx = 0; }


$scope.rotUpperArmLeft  = function() { delta_upperArm_rx = 0.5; }
$scope.rotUpperArmRight = function() { delta_upperArm_rx = -0.5; }
$scope.stopUpperArm     = function() { delta_upperArm_rx = 0; }


//----------------------------------------------------------------------------------------------------------

// function to nav between tabs
$scope.navType = function (type) {
  	// Make all nav labels unselected
    $scope.setWidgetProp('home', 'class', 'label_nav');
    $scope.setWidgetProp('statistics', 'class', 'label_nav');
    $scope.setWidgetProp('movements', 'class', 'label_nav');
  	// Make statistics label selected
    $scope.setWidgetProp(type, 'class', 'label_nav_selected');
  	// Allows highlighting feature
  	highlightActive = true;
  	showAnglesActive = true;

  	
  	// Make correct display visible
  	if (type == 'statistics') {
           $scope.setWidgetProp('display_statistics', 'visible', true);
      	   // Removes highlighting feature
      	   highlightActive = false;
      	   // Remove angle display and make show angles unactive
           $scope.setWidgetProp('display_angles', 'visible', false);
           $scope.view.wdg['h1']['visible'] = false;
      	   showAnglesActive = false;		
        } 
    else {
	     $scope.setWidgetProp('display_statistics', 'visible', false);
    	}
  	
    if (type == 'movements') {
           $scope.setWidgetProp('display_movements', 'visible', true); 
        } 
    else {
	     $scope.setWidgetProp('display_movements', 'visible', false);
    	}
  	
       
}


// function navigate statistics displays

/* NOT USED ANYMORE (NO TIME TO IMPLEMENT, GRAPH PROBLEMS)
$scope.navStatisticsStress = function () {
    // Mark Stress label as selected
    $scope.setWidgetProp('stress', 'class', 'label_nav_statistics_selected');
    // Mark Operation label as unselected
    $scope.setWidgetProp('operation', 'class', 'label_nav_statistics');
}
*/

$scope.navStatisticsOperation = function () {
    // Mark Stress label as unselected
    $scope.setWidgetProp('stress', 'class', 'label_nav_statistics');
    // Mark Operation label as selected
    $scope.setWidgetProp('operation', 'class', 'label_nav_statistics_selected');
}

$scope.navStatisticsType = function (type, chart) {
    // Mark all type labels unselected
    $scope.setWidgetProp('base_nav', 'class', 'label_nav_statistics2');
    $scope.setWidgetProp('lower_nav', 'class', 'label_nav_statistics2');
    $scope.setWidgetProp('middle_nav', 'class', 'label_nav_statistics2');
    $scope.setWidgetProp('upper_nav', 'class', 'label_nav_statistics2');
  	// Hide all charts not to be displayed
  	$scope.setWidgetProp('base_chart', 'visible', false);
    $scope.setWidgetProp('lower_chart', 'visible', false);
    $scope.setWidgetProp('middle_chart', 'visible', false);
    $scope.setWidgetProp('upper_chart', 'visible', false);
    // Mark type label selected
    $scope.setWidgetProp(type, 'class', 'label_nav_statistics2_selected');
  	// Show chart to be displayed
    $scope.setWidgetProp(chart, 'visible', true);

}




// --------------------------------- PLAY MOVEMENTS CODE -------------------------------------------------



$scope.playMovement = function(type) {

 	// Make all play movement labels unselected
    $scope.setWidgetProp('movement1', 'class', 'label_nav_movement');  
    $scope.setWidgetProp('movement2', 'class', 'label_nav_movement');  
    $scope.setWidgetProp('movement3', 'class', 'label_nav_movement');  
  

  	if (type == '1') {
      	// Set movement parameter to true
     	$scope.app.params.play_movement = 1;
      	// Make movement 1 label selected
      	$scope.setWidgetProp('movement1', 'class', 'label_nav_movement_selected');  
    }
  
 	if (type == '2') {
      	// Set movement parameter to true
     	$scope.app.params.play_movement = 2;
      	// Make movement 1 label selected
      	$scope.setWidgetProp('movement2', 'class', 'label_nav_movement_selected');      }  

   	if (type == '3') {
      	// Set movement parameter to true
     	$scope.app.params.play_movement = 3;
      	// Make movement 1 label selected
      	$scope.setWidgetProp('movement3', 'class', 'label_nav_movement_selected');      }
}
