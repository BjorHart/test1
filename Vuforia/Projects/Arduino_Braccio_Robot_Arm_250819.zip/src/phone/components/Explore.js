// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available


// function to redirect to edr home page
$scope.goToEDR = function () {
	window.location.href = 'https://edrmedeso.com/'	  
};
